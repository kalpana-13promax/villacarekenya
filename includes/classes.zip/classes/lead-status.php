<?php

class leads extends db
{



function lead_status ()
{
    date_default_timezone_set("Asia/Muscat");
    foreach($_POST as $key => $value )
    {
        if($key & $value){
            $post[$key] = $value; //Thsi array holds all post data now.
            if (array_key_exists('edit_key', $post) OR array_key_exists('edit_value', $post)) {
                // no need of any statement blank for not include edit in array
            }else{
            $array[$key] = $value; //Thsi array holds all post data now.
            }
           }
    } 
      $table =  'lead_status';
     //echo "<br />";
     //print_r($array);
    //die;
   $nav = $_GET['nav'];
$data = $this->insert_query($table, $array);
$this->msg_set($data, $nav);
}

}



if(isset($_POST['lead-status']))
{
	$obj = new leads();
	$obj->lead_status ();
}

