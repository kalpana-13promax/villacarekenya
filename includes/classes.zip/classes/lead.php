<?php

class lead extends db
{
	
	function lead_add ()
	{
		session_start();

date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
        
           
		if($_POST['source_id']==1){

			$agent_id=$_POST['agent_id'];


		}elseif($_POST['source_id']==2){

        $agent_id=$_POST['staff_id'];

		}else{

			$agent_id="";
		}

if(isset($_POST['interested_property'])){
		$arr = $_POST['interested_property'];
		$interested_properties = implode(", ",$arr);
}else{
	$interested_properties = '';

}		

if(isset($_POST['location'])){
		$location = $_POST['location'];
		$lead_location = implode(", ",$location);
}else{
	$lead_location = '';
}
if(isset($_POST['category'])){
		$category = $_POST['category'];
		$lead_category = implode(", ",$category);
}else{
	$lead_category = '';
}
if(isset($_POST['property_type'])){
		$property_type = $_POST['property_type'];
		$lead_property_type = implode(", ",$property_type);
}else{
	$lead_property_type = '';
}


if(!empty($_POST['lead_contact'])){
	$lead_contact = $_POST['lead_contact'];
	$data = $this->getQuery("SELECT * FROM leads WHERE lead_contact = '$lead_contact' ")??[];
	if(!empty($data)){
		$_SESSION['fal'] = 'Contact already exists';
		header("location: ?nav=leads");
		die;
	}
}

		$array = array(
			'lead_name' => $_POST['lead_name'],
			'c_code' => $_POST['c_code'],
			'lead_contact' => $_POST['lead_contact'],
			'a_code' => $_POST['a_code'],
			'alternate_contact'=>$_POST['alternate_contact'],
			'lead_mail' => $_POST['lead_mail'], 
			'lead_location' => $_POST['lead_location'], 

			'interested_property' => $interested_properties,
			'required_date' => $_POST['required_date'],

			'property_size_min' => $_POST['req_min_area'], 
			'property_size_max' => $_POST['req_max_area'], 
			'client_budget_min' => $_POST['budget_min'], 
			'client_budget_max' => $_POST['budget_max'], 
			'deposit' => $_POST['deposit'], 
			'loan_requirement' => $_POST['loan_req'], 

			'property_type' => $lead_property_type, 
			'contract' => $_POST['contract'], 
			'category'  => $lead_category,
			'furnished_status'  => $_POST['furnished_status'],
			'required_property_location' => $lead_location, 
			'lead_status' => 'un-attempted', 
			'reference' => $_POST['source_id'], 
			'agent_id' => $agent_id, 
			'lead_uploaded_by' => $_POST['user'], 
			'lead_date' => $date_time, 
			 'project' =>$_POST['project'],
			 'lead_type' => $_POST['lead_type'],
			'machine_name' => 'Macbook', 
			'browser' => 'Safari', 
			'host_ip' => 'private',
			'remarks'=>$_POST['remarks']
		);



//  echo "<pre>";
//   print_r($array);
//  echo "</pre>";
 $csrf=$_POST['csrf_token'];
//   die;
		$data = $this->csrf_insert('leads', $array,$csrf);
		
		$last_id = $this->mysqli->insert_id;

		date_default_timezone_set("Asia/Kolkata");
		$date_time =    date("Y-m-d h:i:sa");
		$today=  date("Y-m-d h:i:sa");
	   
		$act= array(
			'user_id' =>$_POST['user_id'],
			'action' =>"New Lead ".$_POST['lead_name']." (".$last_id.") Added",
			
	   
		);
		$data1 = $this->insert_query('user_actvity', $act);
		
		$lead_name = $_POST['lead_name'];
		$lead_contact = $_POST['lead_contact'];
		
		$alternate_contact=$_POST['alternate_contact'];
		$lead_mail = $_POST['lead_mail'];
		$lead_location = $_POST['lead_location'];
		$property_type = $_POST['property_type'];
		$contract = $_POST['contract'];
		$category  = $_POST['category'];
		$furnished  = $_POST['furnished_status'];
		$rpl = $_POST['location'];
		$lead_status = 'un-attempted';
		$ref = $_POST['source_id'];
		$agent_id = $agent_id;
		
		 
	
		$remarks=$_POST['remarks'];
		
// echo "<pre>";
//      print_r($array);
// echo "</pre>";
// die;

if( $data ){
	
$admin=$this->getQuery("select id from user where usertype='root'");
    $adminUserIds=(array) $admin;
    $vars=[];
    
    $payload = json_encode([
        'lead_id'    => $last_id,
        'admin_ids'  => $adminUserIds,
        'vars'=>['crm_link'=>BASEURL]
    ]);
    $this->mysqli->query("INSERT INTO jobs (type, payload) VALUES ('new_lead', '$payload')");
}




        
        
        
		if($data)
		{


			$_SESSION['suc'] = 'Lead Added Successfully';
			header("location:?nav=leads");
			die;
		}
		else
		{
			$_SESSION['fal'] = ' not insert, Something wrong or Duplicate Record Found!' . $_POST['lead_name'] . " " . $this->mysqli->error;
			
			
			header("location: ?nav=leads&name=$lead_name&contact=$lead_contact&alternate=$alternate_contact&mail=$lead_mail&location=$lead_location&property_type=$property_type&contract=$contract&category=$category&furnished=$furnished&rpl=$rpl&ref=$ref&agent_id=$agent_id");
			die;
	
		}
		header("location: lead-add/?nav=leads");
			//header("location: ?nav=leads&name=$lead_name&contact=$lead_contact&alternate=$alternate_contact&mail=$lead_mail&location=$lead_location&property_type=$property_type&contract=$contract&category=$category&furnished=$furnished&rpl=$rpl&ref=$ref&agent_id=$agent_id");
		die;
	}
    
    
    
    function remarks_add ()
	{
		
		date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
        
        
        $lead_id    =   $_POST['lead_id'];

		
		$array = array(
			'remarks' => $_POST['remarks'],
			'lead_id' => $lead_id,
			'remarks_by' => $_POST['user'], 
			'remarks_date' => $date_time, 
			'host' => 'private', 
			'ip' => 'private', 
			'machine_name' => 'Macbook', 
			'browser' => 'Safari' 
		);
		$data = $this->insert_qry('remarks', $array);


// 		activity

$last_id = $this->mysqli->insert_id;

		date_default_timezone_set("Asia/Kolkata");
		$today=  date("Y-m-d h:i:sa");
	   
		$act= array(
			'user_id' =>$_POST['user_id'],
			'action' =>"Remaks ".$_POST['remarks']." (".$last_id.") Added",
			
	   
		);
		$data = $this->insert_query('user_actvity', $act);
// activity
		
		
		
		
		session_start();
        
        
        
		if( $data )
		{
			$_SESSION['suc'] = 'Remarks Added!';
		}
		else
		{
			$_SESSION['fal'] = ' not insert, Something wrong or Duplicate Record Found!' . $this->mysqli->error;
		}
			header("location: ?edit=$lead_id");
			die;
	}
	
	 function update_lead_remarks ()
	{
		
		date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
        
        
        $lead_id    =   $_POST['lead_id'];

		
		$array = array(
			'remarks' => $_POST['remarks'],
			 
		);
		
		$where="id=".$_GET['edit'];
		
		$edit = $_GET['edit'];
		$data = $this->update_qry('leads', $array,$where);


		
		
		session_start();
        
        
        
		if( $data )
		{
			$_SESSION['suc'] = 'Remark Updated!';
		}
		else
		{
			$_SESSION['fal'] = ' not updated, Something wrong' . $this->mysqli->error;
		}
			header("location: ?edit=$edit");
			die;
	}
	
	
    
    
    
      function remarks_update ()
	{
		
		date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
        
        
        $lead_id    =   $_POST['lead_id'];

		
		$array = array(
			'remarks' => $_POST['remarks'],
			 
		);
		
		$where="id=".$_GET['redit'];
		$edit=$_GET['edit'];
		
		$data = $this->update_qry('remarks', $array,$where);


		// activity


date_default_timezone_set("Asia/Kolkata");
$today=  date("Y-m-d h:i:sa");

$act= array(
	'user_id' =>$_POST['user_id'],
	'action' =>"Remaks ".$_POST['remarks']." (".$_GET['edit'].") Updated",
	

);
$data = $this->insert_query('user_actvity', $act);
// activity

		
		session_start();
        
        
        
		if( $data )
		{
			$_SESSION['suc'] = 'Remark Updated!';
		}
		else
		{
			$_SESSION['fal'] = ' not updated, Something wrong' . $this->mysqli->error;
		}
			header("location: ?edit=$edit");
			die;
	}
    
    
    
    
    
    function lead_edit ()
	{
		
		if(isset($_POST['location'])){
			$location = $_POST['location'];
			$lead_location = implode(", ",$location);
    	}else{
		$lead_location = '';
	    }
        
        
        
        if(isset($_POST['category'])){
		$category = $_POST['category'];
		$lead_category = implode(", ",$category);
}else{
	$lead_category = '';
}
if(isset($_POST['property_type'])){
		$property_type = $_POST['property_type'];
		$lead_property_type = implode(", ",$property_type);
}else{
	$lead_property_type = '';
}
        
        date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
		
        $lead_id    =   $_POST['lead_id'];
         
		$reference = $_POST['source_id'];

		if($reference==1){
     
            $agent_id=$_POST['agent_id'];

		}elseif($reference==2){

           $agent_id=$_POST['staff_id'];


		}else{

        $agent_id=NULL;
		}
		
		 $nofollow = $_POST['no_follow'];
		 
		 $assign = $_POST['assign'];
		 $staffid = $_POST['staffid'];
		 if($assign = 'public'){
		  $assign_to = $staffid;   
		 }else{
		     $assign_to = $assign;
		 }
		
		$array = array(
			'lead_name' => $_POST['lead_name'],
			'c_code' => $_POST['c_code'],
			'lead_contact' => $_POST['lead_contact']??'',
			'a_code' => $_POST['a_code'],
			'alternate_contact' => $_POST['alternate_contact'],
			'lead_mail' => $_POST['lead_mail'], 
			'lead_location' => $_POST['lead_location'], 
			'project' => $_POST['project'], 
			'property_type' => $lead_property_type, 
			'category'  => $lead_category,
			'furnished_status'  => $_POST['furnished_status'],
			'contract' => $_POST['contract'], 
			'required_property_location' => $lead_location, 
			'property_size_min' => $_POST['req_min_area'], 
			'property_size_max' => $_POST['req_max_area'], 
			'client_budget_min' => $_POST['budget_min'], 
			'client_budget_max' => $_POST['budget_max'], 
			'deposit' => $_POST['deposit'], 
			'loan_requirement' => $_POST['loan_req'],
			'reference' => $_POST['source_id'], 
			'agent_id' => $agent_id, 
			'lead_status' => $_POST['lead_status'],
			'followup' => $nofollow,
			'update_by' => $_POST['user'],
			'lead_call_status' => $_POST['call_status'],
			'mark_color' => $_POST['color'],
			'follow_up_date' => $_POST['follow_date'],
			'follow_up_time' => $_POST['follow_time'],
			'assign_to' => $assign_to,
		  'project' =>$_POST['project'],
		   'lead_type' => $_POST['lead_type'],
			'machine_name' => 'Macbook', 
			'browser' => 'Safari', 
			'host_ip' => 'Private'
		
		);
		$csrf = $_POST['csrf_token'];
	//	$where = $_POST['id'];
		$where = "id = " . $lead_id ;
		$data = $this->csrf_update('leads', $array, $where,$csrf);


		
// activity

date_default_timezone_set("Asia/Kolkata");
		$date_time =    date("Y-m-d h:i:sa");
		$today=  date("Y-m-d h:i:sa");
	   
		$act= array(
			'user_id' =>$_POST['user_id'],
			'action' =>" Lead ".$_POST['lead_name']." (".$lead_id.") Updated",
			
	   
		);
		$this->insert_query('user_actvity', $act);

// activity

		// session_start();      
		if( $data ){
				$_SESSION['suc'] = 'Lead Updated!';

			}else{
				$_SESSION['fal'] = ' Failed! '. $this->mysqli->error;
				
			}
			header("location: ?edit=$lead_id");
die;
	}

function lead_assign ()
	{
        
        date_default_timezone_set("Asia/Kolkata");
        $date_time =    date("Y-m-d h:i:sa");
		$date = date("Y-m-d");
         $lead_id    =   $_POST['lead_id'];
        //echo "<br /> Assgin to agent id:" . $assign    =   $_POST['assign'];
        
        

		$array = array(
			'assign_to' => $_POST['assign'],
			'assign_date' => $date
			
		);
		$notification=array(
			'assing_to' => $_POST['assign'],
			'lead_id'=>$_POST['lead_id'],
			'title'=>'Assign To Lead',
			'description'=>'You have been assigned a lead',
			'uploader'=>$_POST['user']
             
		);
// 		print_r($array);
// 		die;
		//$where = $_POST['id'];
		$where = "id = " . $_POST['lead_id'];
		 $data = $this->update_query('leads', $array, $where);
		 $data2= $this->insert_qry('notification', $notification);
$lead=$_POST['lead_id'];
$adetail = $this->getQuery("SELECT * from leads where id=$lead");
$assign=$adetail[0];
$uid=$_POST['assign'];
$udetail = $this->getQuery("SELECT * from user where id='$uid'");
$ud=$udetail[0];

		
		$date_time =    date("Y-m-d h:i:sa");
		$today=  date("Y-m-d h:i:sa");
	   
		$act= array(
			'user_id' =>$_POST['user_id'],
			'action' =>"Lead ".$assign->lead_name." Assigned to ".$ud->name." ",
			
	   
		);
		$data = $this->insert_query('user_actvity', $act);




		session_start();
               
        
	if( $data ){
			if($data2){
			$_SESSION['suc'] = 'Lead Updated!';
			}
		}else{
			$_SESSION['fal'] = ' not insert, Something wrong or Duplicate Record Found!' . $this->mysqli->error;
			
		}
			header("location: ?nav=leads");
			die;
		}






		function import(){
			$uploader	=	$_POST['uploader'];
			$source	=	$_POST['source_id'];
			$public	=	$_POST['public'];
			if($public){
				$assign_to = "public";
			} else{
				$assign_to = $_POST['assign_import'];
			}
				if(isset($_POST["import"])){
				
					$imported = 0;
					$duplicate =0;
					$filename=$_FILES["file"]["tmp_name"];    
					 if($_FILES["file"]["size"] > 0)
					 {
						$file = fopen($filename, "r");
						  while (($getData = fgetcsv($file, 10000, ",")) !== FALSE)
						   {
		$sql = "INSERT into leads (lead_name,lead_contact,lead_mail,lead_location, project, remarks, lead_status, reference, lead_uploaded_by, assign_to, lead_date) 
	values ('".$getData[0]."','".$getData[1]."','".$getData[2]."','".$getData[3]."','".$getData[4]."','".$getData[5]."','un-attempted','".$source."', '".$uploader."','".$assign_to."', '".date('d/m/Y h:i:sa')."')";
								// 	$lc = $getData[1];
								//   $getlead = $this->mysqli->query("SELECT * FROM leads where lead_contact = $lc "); 
								// 	if( $getlead->num_rows )
								// 	{
								// 		$duplicate++;
								//   } else{
								   $data = $this->mysqli->query($sql);
								   $imported++;
								//   }
							
						   } }
						  // 	print_r($sql);
						  // die;
						   
						   session_start();
						   if( $data )
						   
						   {
						       date_default_timezone_set("Asia/Kolkata");
		$today=  date("Y-m-d h:i:sa");
	   
		$act= array(
			'user_id' =>$_POST['user_id'],
			'action' =>" Lead  import",
			
	   
		);
		$activity = $this->insert_query('user_actvity', $act);
							   $_SESSION['suc'] = $imported. ' Import Successfully, Duplicate: '. $duplicate;
						   }
						   else
						   {
				 $_SESSION['fal'] = ' Not Import, Something went wrong! or Duplicate : '.$duplicate ." - ". $this->mysqli->error;
						   }
							   header("location: ?nav=leads");
							   die;
						   fclose($file);  
						   exit();
					 }
				//   }   
				}
			
			
			
			
				
				
				function lead_export(){
					if(isset($_POST["export"])){
                        date_default_timezone_set("Asia/Kolkata");
						$today=  date("Y-m-d h:i:sa");
					   
						$act= array(
							'user_id' =>$_POST['user_id'],
							'action' =>" Lead export",
							
					   
						);
						$activity = $this->insert_query('user_actvity', $act);


						$staff = $_POST['staff'];
						$lead_status = $_POST['lead_status'];
						$where = "";
						$staff_id = '';
						
						if($staff=='all'){
							$where = '';
						}else{
							$staff_id = " assign_to = '$staff'";
						}


						if($lead_status=='all'){
                        $lead_status='';
						}elseif($lead_status=='un-attempted'){
							$leads_status = " lead_status = 'un-attempted' ";
						}elseif($lead_status=='not-interested'){
							$leads_status = " lead_status = 'not-interested' ";
						}elseif($lead_status=='today'){
							$leads_status = " follow_up_date = CURDATE() ";
						}elseif($lead_status=='upcomming'){
							$leads_status = " follow_up_date > CURDATE() ";
						}elseif($lead_status=='old'){
							$leads_status = " follow_up_date < CURDATE() ";
						}else{
						    $leads_status=" lead_status = '$lead_status' ";
						}
// echo $lead_status;
// die;


						if($staff_id){
							$where = $staff_id;
						}

						if($lead_status){
							if($staff_id){
								$where .= " AND ";
							}
							$where .= $leads_status;
						}


						if($staff_id || $lead_status){
							$search = " WHERE ". $where;
						}else{
							$search = '';
						}

// echo "SELECT id, lead_name, c_code, lead_contact, a_code, alternate_contact, lead_mail, lead_location, contract, category, lead_for, required_property_location, interested_property, property_size_min, property_size_max, client_budget_min, client_budget_max, follow_up_date, lead_status, lead_call_status, lead_date from leads $search ORDER BY id DESC";
// die;
				// 		echo "SELECT id, lead_name, lead_contact, lead_mail, lead_location, lead_date from leads $search ORDER BY id DESC"; //);  
				// 				die;
						ob_start();
			
						header('Content-Type: text/csv; charset=utf-8');  
						header('Content-Disposition: attachment; filename=data.csv');
						header('Cache-Control: no-cache');
						//header('Content-Length: '. ob_get_length());
			
						
						$output = fopen("php://output", "w");  
						fputcsv($output, array('ID', 'NAME', 'ISD', 'CONTACT', 'ISD', 'ALT-CONTACT', 'EMAIL', 'LOCATION', 'CONTRACT', 'CATEGORY', 'FOR', 'REQUIRED LOCATION', 'INTERESTED PROPERTY', 'MIN_SIZE', 'MAX-SIZE', 'BUDGET-MIN', 'BUDGET-MAX', 'FOLLOW-UP DATE', 'STATUS', 'CALL STATUS', 'DATE'));  
	$exp = $this->mysqli->query("SELECT id, lead_name, c_code, lead_contact, a_code, alternate_contact, lead_mail, lead_location, contract, category, lead_for, required_property_location, interested_property, property_size_min, property_size_max, client_budget_min, client_budget_max, follow_up_date, lead_status, lead_call_status, lead_date from leads $search ORDER BY id DESC");  
						
						
						while($row = mysqli_fetch_assoc($exp))  
						{  
							 fputcsv($output, $row);  
						}  
						$streamSize = ob_get_length();
						header('Content-Length: '. ob_get_length());
			
						// Flush (send) the output buffer and turn off output buffering
						ob_end_flush();
						fclose($output);
						exit();
				   }  
				  }
				  
				  
				  
// 				function lead_export(){
// 					if(isset($_POST["export"])){

// 						$staff = $_POST['staff'];
// 						$lead_status = $_POST['lead_status'];
// 						$where = "";
// 						$staff_id = '';
						
// 						if($staff=='all'){
// 							$where = '';
// 						}else{
// 							$staff_id = " assign_to = '$staff'";
// 						}


// 						if($lead_status=='all'){
// $lead_status='';
// 						}elseif($lead_status=='un-attempted'){
// 							$leads_status = " lead_status = 'un-attempted' ";
// 						}elseif($lead_status=='not-interested'){
// 							$leads_status = " lead_status = 'not-interested' ";
// 						}elseif($lead_status=='today'){
// 							$leads_status = " follow_up_date = CURDATE() ";
// 						}elseif($lead_status=='upcomming'){
// 							$leads_status = " follow_up_date > CURDATE() ";
// 						}elseif($lead_status=='old'){
// 							$leads_status = " follow_up_date < CURDATE() ";
// 						}


// 						if($staff_id){
// 							$where = $staff_id;
// 						}

// 						if($lead_status){
// 							if($staff_id){
// 								$where .= " AND ";
// 							}
// 							$where .= $leads_status;
// 						}


// 						if($staff_id || $lead_status){
// 							$search = " WHERE ". $where;
// 						}else{
// 							$search = '';
// 						}

// 						//echo "SELECT id, lead_name, lead_contact, lead_mail, lead_location, lead_date from leads $search ORDER BY id DESC"; //);  
// 						//		die;
// 						ob_start();
			
// 						header('Content-Type: text/csv; charset=utf-8');  
// 						header('Content-Disposition: attachment; filename=data.csv');
// 						header('Cache-Control: no-cache');
// 						//header('Content-Length: '. ob_get_length());
			
						
// 						$output = fopen("php://output", "w");  
// 						fputcsv($output, array('ID', 'NAME', 'ISD', 'CONTACT', 'ISD', 'ALT-CONTACT', 'EMAIL', 'LOCATION', 'CONTRACT', 'CATEGORY', 'FOR', 'REQUIRED LOCATION', 'INTERESTED PROPERTY', 'MIN_SIZE', 'MAX-SIZE', 'BUDGET-MIN', 'BUDGET-MAX', 'FOLLOW-UP DATE', 'STATUS', 'CALL STATUS', 'DATE'));  
// 						$exp = $this->mysqli->query("SELECT id, lead_name, c_code, lead_contact, a_code, alternate_contact, lead_mail, lead_location, contract, category, lead_for, required_property_location, interested_property, property_size_min, property_size_max, client_budget_min, client_budget_max, follow_up_date, lead_status, lead_call_status, lead_date from leads $search ORDER BY id DESC");  
						
						
// 						while($row = mysqli_fetch_assoc($exp))  
// 						{  
// 							 fputcsv($output, $row);  
// 						}  
// 						$streamSize = ob_get_length();
// 						header('Content-Length: '. ob_get_length());
			
// 						// Flush (send) the output buffer and turn off output buffering
// 						ob_end_flush();
// 						fclose($output);  
// 				   }  
// 				  }
				  
				  
				  function bluk_assign(){
					date_default_timezone_set("Asia/Kolkata");
					$date_time =    date("Y-m-d h:i:sa");
					$date = date("Y-m-d");
					$array = array(
						'assign_to' => $_POST['bassign'],
						'assign_date' => $date
						
					);
				
							
					$lead_id =  implode(",",$_POST['lead_id']);	
					// echo $lead_id;
					$l=explode(",",$lead_id);
					foreach ($l as $lead_id)
					 {
						
			
					$where = "id = " . $lead_id;   
					// echo $where;
					
					$data = $this->update_query('leads', $array, $where);
					 }
				
					 session_start();
					   
				
					 if( $data ){
						 $_SESSION['suc'] = 'Lead Updated!';
			 
					 }else{
						 $_SESSION['fal'] = ' not insert, Something wrong or Duplicate Record Found!' . $this->mysqli->error;
						 
					 }
						 header("location: ?nav=leads");
						 die;
					 }
		
		




    
}
	

if(isset($_POST['lead-add']))
{
	$obj = new lead();
	$obj->lead_add ();
}

if(isset($_POST['remarks-add']))
{
	$obj = new lead();
	$obj->remarks_add ();
}

if(isset($_POST['update-lead-remarks']))
{
	$obj = new lead();
	$obj->update_lead_remarks ();
}


if(isset($_POST['lead-edit']))
{
	$obj = new lead();
	$obj->lead_edit ();
}
if(isset($_POST['assign']))
{
	$obj = new lead();
	$obj->lead_assign ();
}


if(isset($_POST['remarks-update']))
{
	$obj = new lead();
	$obj->remarks_update ();
}


if(isset($_POST['import']))
{
	$obj = new lead();
	$obj->import ();
}
if(isset($_POST['export']))
{
	$obj = new lead();
	$obj->lead_export ();
}


if(isset($_POST['bluk_assign'])){
	$obj = new lead();
	$obj->bluk_assign();
}

?>